<template>
  <div class="rcd-page">
    <div class="dash-wrap">
      <!-- ================= 查询条件 ================= -->
      <div class="card">
        <div class="toolbar toolbar--flat">
          <div class="tb-l dash-q">
            <span class="hint">机构</span>
            <select class="sel" v-model="form.scope">
              <option value="ALL">全省（60 家法人行）</option>
              <option v-for="o in banks" :key="o" :value="o">{{ o }}</option>
            </select>
            <span class="hint">年度</span>
            <select class="sel" v-model="form.year">
              <option v-for="y in years" :key="y" :value="y">{{ y }}</option>
            </select>
            <span class="hint">统计时间</span>
            <select class="sel" v-model="form.period">
              <option v-for="p in periods" :key="p" :value="p">{{ p }}</option>
            </select>
            <span class="hint">招聘类型</span>
            <select class="sel" v-model="form.qtype">
              <option v-for="t in qtypes" :key="t" :value="t">{{ t }}</option>
            </select>
            <button class="btn btn-pri" @click="onQuery">查询</button>
            <button class="btn" @click="onReset">重置</button>
          </div>
          <div class="tb-r">
            <button class="btn" title="按当前筛选条件（机构 / 年度 / 类型）实时汇总导出" @click="onExport">导出</button>
            <button class="btn btn-pri" @click="onReport">生成报表</button>
          </div>
        </div>
      </div>

      <!-- ================= KPI ================= -->
      <div class="stat-row stat-row--4">
        <div
          v-for="(k, i) in kpis"
          :key="k.l"
          class="stat-c kpi"
          :style="{ '--ac': k.ac, '--ac2': k.ac2, '--ac-s': k.acs }"
          @click="onKpi(k)"
        >
          <div class="kp-h">
            <div class="sl">{{ k.l }}</div>
            <i class="kp-ic" v-html="KPI_ICONS[i]"></i>
          </div>
          <div class="sv">{{ k.v }}</div>
          <div class="ss">
            <span v-if="k.act" class="ss-act">{{ k.act }}</span>
            <template v-if="k.act"> · </template>{{ k.s }}
          </div>
        </div>
      </div>

      <div class="grid3 mt12">
        <!-- ================= 重点计划实施进度 ================= -->
        <div class="card tone-blue">
          <div class="card-h">
            <h3>重点计划实施进度</h3>
            <button class="lnk" @click="onViewAllImpl">查看全部计划 →</button>
          </div>
          <div class="card-b">
            <template v-if="focusList.length">
              <div v-for="f in focusList" :key="f.im.id" class="impl-item">
                <div class="impl-row">
                  <div class="impl-title">
                    <button class="impl-name" title="点击进入计划" @click="onViewImpl(f.im)">{{ f.im.name }}</button>
                    <div class="hint">
                      <template v-if="cur.scope === 'ALL'">{{ f.im.org }} · </template>{{ f.im.type }} · 招聘{{ f.im.headcount }}人
                      <template v-if="f.gap > 0"> · <b style="color:#e23b3b">缺口{{ f.gap }}人</b></template>
                      · 拟录用{{ f.im.progress.planned }}人 · 当前环节：<b>{{ f.im.progress.inflight > 0 ? f.im.flow[2] || f.im.flow[0] : "未启动" }}</b>
                    </div>
                  </div>
                  <span class="tag" :class="'tag-' + f.tone">{{ f.t }}</span>
                </div>
                <div class="impl-prog">
                  <div class="prog" :class="{ bad: f.t === '超期', warn: f.t === '预警' }" style="flex: 1">
                    <span :style="{ '--w': f.rate + '%', width: f.rate + '%' }"></span>
                  </div>
                  <span class="impl-pct">完成率 {{ f.rate }}%</span>
                </div>
              </div>
            </template>
            <div v-else class="empty">当前筛选条件下暂无重点计划</div>
          </div>
        </div>

        <!-- ================= 待办事项 ================= -->
        <div class="card tone-indigo">
          <div class="card-h">
            <h3>待办事项（共 {{ todoAll.length }} 项）</h3>
            <button class="lnk" @click="onTodoAll">查看全部 →</button>
          </div>
          <div class="card-b">
            <div v-for="t in todos" :key="t.id" class="todo-i">
              <span class="tag" :class="'tag-' + todoTone(t.type)">{{ t.type }}</span>
              <div class="todo-main">
                <div class="todo-title">{{ t.title }}</div>
                <div class="hint">{{ t.org }} · {{ t.time }}</div>
              </div>
              <button class="btn" @click="onTodoGo(t)">办理</button>
            </div>
            <div v-if="!todos.length" class="hint" style="padding: 6px 0">当前范围暂无待办。</div>
            <div class="hint" style="margin-top: 8px">
              {{ todoAll.length > 5 ? "还有 " + (todoAll.length - 5) + " 项待办未显示，点击「查看全部」查看。" : "" }}
            </div>
          </div>
        </div>

        <!-- ================= 风险预警 ================= -->
        <div class="card tone-rose">
          <div class="card-h">
            <h3>风险预警</h3>
            <button class="lnk" title="风险预警时间参数配置" @click="onRiskCfg">⚙ 预警配置</button>
            <div class="tb-l risk-filter">
              <button
                v-for="c in riskChips"
                :key="c.lv"
                class="tag risk-chip"
                :class="['tag-' + c.cls, { 'risk-chip--on': riskLv === c.lv }]"
                :title="'点击按' + c.label + '筛选'"
                @click="toggleRisk(c.lv)"
              >
                {{ c.label }} {{ c.count }}
              </button>
              <button v-if="riskLv" class="lnk" title="取消筛选，显示全部风险" @click="riskLv = ''">显示全部 ✕</button>
            </div>
          </div>
          <div class="card-b risk-scroll">
            <div v-for="r in riskRows" :key="r.id" class="risk-i">
              <span class="risk-lv" :style="{ background: TONE_DOT[r.lv] }"></span>
              <div class="risk-main">
                <div class="risk-name">{{ r.name }}<span class="hint">｜{{ r.org }}</span></div>
                <div class="hint">{{ r.content }} ｜ 产生时间 {{ r.time }}</div>
              </div>
              <button class="lnk" @click="onRiskView(r)">查看</button>
              <button v-if="r.status !== '已解除'" class="lnk" @click="onRiskUrge(r)">督办</button>
            </div>
            <div v-if="!riskRows.length" class="empty">当前筛选条件下暂无风险记录</div>
          </div>
        </div>
      </div>

      <!-- ================= 招聘统计分析 ================= -->
      <div class="card mt12 tone-teal">
        <div class="card-h">
          <h3>招聘统计分析</h3>
          <span class="hint">
            口径：流程转化按<b>投递记录数</b>；结构与后评价按<b>人数</b>（自然人去重）｜ 当前筛选：<b>{{ scopeLabel }}</b> ·
            {{ cur.year }}年度 · {{ cur.qtype }} · {{ periodLabel }} ｜ 数据随上方查询条件实时联动（流程转化可按计划实施单独过滤）
          </span>
        </div>
        <div class="card-b">
          <div class="grid2">
            <!-- 漏斗 -->
            <div>
              <div class="sec-t">
                招聘流程转化（纵向漏斗）
                <span style="margin-left: auto; display: flex; align-items: center; gap: 6px; font-weight: 400">
                  <span class="hint" style="margin: 0">计划实施</span>
                  <select
                    class="sel"
                    v-model="dimpl"
                    style="min-width: 200px"
                    title="仅招聘流程转化跟计划实施绑定：选中具体实施后，漏斗仅统计该实施的投递记录"
                  >
                    <option value="">全部计划实施</option>
                    <option v-for="im in scopeImpls" :key="im.id" :value="im.id">{{ im.name }}（{{ im.status }}）</option>
                  </select>
                </span>
              </div>
              <template v-if="funnel[0].v > 0">
                <div
                  v-for="(f, i) in funnel"
                  :key="f.n"
                  class="fun-row"
                  :style="{ '--fc': FR[i % 7][0], '--fc2': FR[i % 7][1], '--fc-s': FR[i % 7][2] }"
                >
                  <span>{{ f.n }}</span>
                  <div class="fun-bar">
                    <span :style="{ '--w': barW(f.v) + '%', width: barW(f.v) + '%' }"></span>
                  </div>
                  <div class="fun-cv">
                    <b>{{ f.v }}</b>
                    <template v-if="i > 0"> ｜ {{ pct(f.v, funnel[i - 1].v) }}%</template>
                  </div>
                </div>
                <div class="hint">
                  总体转化率（投递→确认入职）：<b style="color: var(--primary)">{{ pct(funnel[6].v, funnel[0].v) }}%</b>
                </div>
              </template>
              <div v-else class="empty">当前筛选条件下暂无招聘流程数据</div>
            </div>

            <!-- 入职人员结构 -->
            <div>
              <div class="sec-t">
                入职人员结构（确认入职人员）
                <span style="margin-left: auto; font-weight: 400">
                  <button
                    v-for="k in dimKeys"
                    :key="k"
                    class="lnk"
                    :style="k === dim ? 'font-weight:700;text-decoration:underline' : ''"
                    @click="dim = k"
                  >
                    {{ k }}
                  </button>
                </span>
              </div>
              <div class="hint" style="margin-bottom: 6px">
                口径与上方「确认入职人数」一致（{{ scopeLabel }} · {{ cur.year }} · {{ cur.qtype === "全部" ? "校招+社招" : cur.qtype }}），
                结构合计 = 确认入职人数。
              </div>
              <div v-if="donutTotal > 0" class="donut-wrap">
                <div class="donut" :style="{ background: donutGrad }">
                  <div class="donut-c">
                    <div>
                      <b>{{ donutTotal }}</b>
                      <span>确认入职</span>
                    </div>
                  </div>
                </div>
                <ul class="lgd">
                  <li v-for="d in donutRows" :key="d.n">
                    <span class="dot" :style="{ background: d.c }"></span>{{ d.n }}
                    <span class="lg-n">{{ d.v }}人 · {{ pct(d.v, donutTotal) }}%</span>
                  </li>
                </ul>
              </div>
              <div v-else class="empty">当前筛选条件下暂无入职人员结构数据</div>
              <div class="hint" style="margin-top: 8px">
                分析结论：录用人员以硕士与本科为主；「笔试」环节人员流失较多。
                <button class="lnk" @click="onGotoCandidate">查看人员明细 →</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- ================= 招聘后评价 ================= -->
      <div class="card mt12 tone-amber">
        <div class="card-h">
          <h3>招聘后评价</h3>
          <span class="hint">
            统计范围：{{ evalScopeLabel }} · {{ cur.year }}年度 ｜ 统计期内确认入职且完成试用期考核人员（数据来源于人力系统考核模块，只读同步）
          </span>
        </div>
        <div class="card-b">
          <!-- 计划实施选择器：评价流程由所选计划实施确定 -->
          <div class="eval-scope">
            <span class="hint" style="margin: 0">计划实施</span>
            <select
              class="sel"
              v-model="evalImpl"
              style="min-width: 300px"
              title="招聘后评价跟随计划实施确定：选择具体实施后，入职与考核数据均取自该实施"
            >
              <option value="">全部计划实施（{{ cur.scope === "ALL" ? "全省合计" : "本行合计" }}）</option>
              <option v-for="im in evalImplOpts" :key="im.id" :value="im.id">
                {{ im.name }}（入职 {{ im.progress.onboard }} 人）
              </option>
            </select>
            <span class="hint">仅列出已产生确认入职的计划实施（未入职 / 草稿 / 审批中的实施暂无评价数据）</span>
          </div>

          <div v-if="evalImplObj" class="rule-bar">
            <b>评价链路（由该计划实施确定）：</b>计划实施「{{ evalImplObj.name }}」招聘流程（{{ evalImplObj.flow.join(" → ") }}）→
            确认入职 <b>{{ evalImplObj.progress.onboard }}</b> 人 → 该批人员试用期考核结果如下。
          </div>

          <!-- 指标区（只看考核口径：入职 → 已完成考核 → 通过率） -->
          <div class="eval-nums">
            <div>同期确认入职 <b class="ev-num eval-num" style="color: var(--primary)">{{ es.onboard }}</b> 人</div>
            <div>已完成考核 <b class="ev-num eval-num">{{ es.total }}</b> 人</div>
            <div>
              试用期考核通过率
              <b class="ev-num eval-num" style="color: var(--success)">{{ es.rate }}%</b>
            </div>
            <span class="hint" style="margin-left: auto">
              （已完成考核 ≤ 确认入职：新入职未满试用期不列入；A/B/C 为通过，D 为未通过）
            </span>
          </div>

          <!-- 等级筛选 chips -->
          <div class="eval-grade-row">
            <span class="hint" style="margin-right: 2px">考核等级</span>
            <button
              v-for="g in GRADES"
              :key="g"
              class="tag"
              :style="gradeChipStyle(g)"
              @click="toggleGrade(g)"
            >
              {{ g }}级 {{ es.cnt[g] }}人
            </button>
            <button v-if="grade" class="lnk" title="取消选择" @click="grade = ''">取消选择 ✕</button>
          </div>

          <!-- 全省 + 未选实施 = 各农商行评价明细；单机构或选中实施 = 部门等级分布 -->
          <template v-if="cur.scope === 'ALL' && !evalImplObj">
            <div class="hint" style="margin-bottom: 6px">
              各农商行评价明细（按已完成考核人数降序<template v-if="grade">，仅显示「{{ grade }}级」涉及的机构</template>）；
              <b>点击机构行可切换查看该行评价</b>。
            </div>
            <div class="tbl-scroll">
              <table class="tbl eval-tbl">
                <thead>
                  <tr>
                    <th class="th-sticky">机构</th>
                    <th class="th-sticky">确认入职</th>
                    <th v-for="g in GRADES" :key="g" class="th-sticky" :style="{ color: GRADE_COLOR[g] }">{{ g }}级</th>
                    <th class="th-sticky">已完成考核</th>
                    <th class="th-sticky">通过率</th>
                  </tr>
                </thead>
                <tbody>
                  <tr
                    v-for="row in evalOrgRows"
                    :key="row.org"
                    class="eval-tr"
                    :title="'点击切换查看「' + row.org + '」评价明细'"
                    @click="pickOrg(row.org)"
                  >
                    <td style="text-align: left"><b>{{ row.org }}</b></td>
                    <td>{{ row.es.onboard }}</td>
                    <td
                      v-for="g in GRADES"
                      :key="g"
                      :style="{ color: row.es.cnt[g] ? (g === 'D' ? 'var(--danger)' : GRADE_COLOR[g]) : 'var(--text-3)' }"
                    >
                      {{ row.es.cnt[g] || "—" }}
                    </td>
                    <td><b>{{ row.es.total }}</b></td>
                    <td>{{ row.es.rate }}%</td>
                  </tr>
                  <tr v-if="!evalOrgRows.length">
                    <td colspan="7"><div class="empty">该等级下暂无涉及机构</div></td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div class="rule-bar" style="margin-top: 12px">
              全省 D级（未通过）共 <b>{{ dSum.d }}</b> 人，涉及 <b>{{ dSum.orgs.length }}</b> 家机构<template v-if="dSum.orgs.length">：{{ dSum.orgs.slice(0, 6).join("、") }}{{ dSum.orgs.length > 6 ? " 等" : "" }}</template>。
              点击机构行可下钻查看该行的部门等级分布。
            </div>
            <div class="hint" style="margin-top: 8px">
              <button class="lnk" @click="onViewPeople">查看考核人员明细 →</button>
            </div>
          </template>

          <template v-else>
            <table class="tbl eval-tbl">
              <thead>
                <tr>
                  <th>部门</th>
                  <th v-for="g in GRADES" :key="g" :style="{ color: GRADE_COLOR[g] }">{{ g }}级</th>
                  <th>合计</th>
                  <th>通过率</th>
                </tr>
              </thead>
              <tbody>
                <tr
                  v-for="row in es.m"
                  :key="row.dept"
                  class="eval-tr"
                  :title="'点击查看「' + row.dept + '」等级构成'"
                  :style="dept === row.dept ? 'background: var(--primary-bg)' : ''"
                  @click="pickDept(row.dept)"
                >
                  <td style="text-align: left"><b>{{ row.dept }}</b></td>
                  <td
                    v-for="g in GRADES"
                    :key="g"
                    :style="{ color: row[g] ? GRADE_COLOR[g] : 'var(--text-3)' }"
                  >
                    {{ row[g] || "—" }}
                  </td>
                  <td><b>{{ evalSumOf(row) }}</b></td>
                  <td>{{ rowPass(row) }}%</td>
                </tr>
              </tbody>
            </table>

            <!-- 选中等级 → 部门分布 -->
            <div v-if="grade" class="eval-detail">
              <div class="sec-t">
                「{{ grade }}级」人员主要分布部门
                <button class="lnk" @click="grade = ''">收起 ✕</button>
              </div>
              <div class="hint" style="margin: 4px 0 8px">点击部门可查看其等级构成。</div>
              <div
                v-for="d in gradeRank"
                :key="d.dept"
                class="eval-rank-i"
                :title="'查看「' + d.dept + '」等级构成'"
                style="cursor: pointer"
                @click="pickDept(d.dept)"
              >
                <span style="width: 96px; flex-shrink: 0">{{ d.dept }}</span>
                <div class="eval-bar">
                  <span :style="{ width: Math.round((d.cnt / gradeMax) * 100) + '%', background: GRADE_COLOR[grade] }"></span>
                </div>
                <span style="width: 44px; text-align: right; flex-shrink: 0">{{ d.cnt }}人</span>
              </div>
              <div v-if="!gradeRank.length" class="hint">该等级下暂无人员。</div>
            </div>

            <!-- 选中部门 → 等级构成 -->
            <div v-if="deptRow" class="eval-detail">
              <div class="sec-t">
                「{{ deptRow.dept }}」部门考核等级构成
                <button class="lnk" @click="dept = ''">收起 ✕</button>
              </div>
              <div class="eval-bar-inline">
                <span
                  v-for="g in GRADES"
                  :key="g"
                  :style="{
                    background: GRADE_COLOR[g],
                    width: evalSumOf(deptRow) ? Math.round((deptRow[g] / evalSumOf(deptRow)) * 100) + '%' : '0%'
                  }"
                >
                  {{ deptRow[g] ? g + " " + deptRow[g] : "" }}
                </span>
              </div>
              <div class="hint">
                A {{ deptRow.A }} · B {{ deptRow.B }} · C {{ deptRow.C }} · D {{ deptRow.D }} ｜ 合计
                {{ evalSumOf(deptRow) }} 人 ｜ 通过率 {{ rowPass(deptRow) }}%
                <span style="margin-left: 8px">
                  <button v-for="g in GRADES" :key="g" class="lnk" @click="grade = g">查看{{ g }}级</button>
                </span>
              </div>
            </div>

            <!-- C/D 重点关注 -->
            <div class="rule-bar" style="margin-top: 12px">
              C/D级共 <b>{{ cd.cd }}</b> 人，需重点关注部门：{{ cd.list || "—" }}。
              <button class="lnk" @click="onViewPeople">查看重点关注人员 →</button>
            </div>
            <div class="hint" style="margin-top: 8px">
              <button class="lnk" @click="onViewPeople">查看考核人员明细 →</button>
            </div>
          </template>
        </div>
      </div>

      <div style="height: 8px"></div>
    </div>
  </div>
</template>

<script>
/**
 * 招聘驾驶舱（招聘模块原型图 · class="dash-wrap" 节点）
 * ------------------------------------------------------------
 * 原型是 pageDashboard() 里的一坨模板字符串 + onclick 事件委托（data-act="xxx"）。
 * 这里做的是「把同样的 DOM 结构交给 Vue 渲染」：
 *
 *   · 结构逐块对照原型 2711~2895 行，样式逐条对照 493~590 行（见 dash.scss）；
 *   · 原型靠 S.xxx 全局状态 + render() 整页重绘，这里换成 data / computed：
 *     改筛选条件 → 计算属性重算 → 只重渲染受影响的那几块；
 *   · 原型 data-act 的点击全部换成方法，行为不变（跳转仍用 toast 代替，
 *     因为本 demo 只注册了这一个路由）。
 *
 * 与原型的唯一结构差异：查询条多了「机构」下拉。原型里机构来自左侧
 * 机构树（dash-wrap 之外的 .org-tree），本页要自包含，就把它挪进了查询条件；
 * 后评价表格点机构行下钻 -> 同样落在这个下拉上。
 */
import {
  BANKS, LEGAL_BANKS, YEARS, PERIODS, QTYPES, KPI_ICONS, GRADES, GRADE_COLOR,
  TONE_DOT, TODO_TONE, TODOS,
  planStat, implsOf, planRisk, funnelOf, dimsOf, conicOf,
  risksOf, evalStats, evalStatsImpl, evalSumOf, pct as pctOf,
} from './mock'

/** 漏斗 7 级的递进色阶（冷 → 暖 → 达成绿） */
const FR = [
  ['#3b82f6', '#93c5fd', 'rgba(59,130,246,.55)'],
  ['#0ea5e9', '#7dd3fc', 'rgba(14,165,233,.55)'],
  ['#06b6d4', '#67e8f9', 'rgba(6,182,212,.55)'],
  ['#14b8a6', '#5eead4', 'rgba(20,184,166,.55)'],
  ['#8b5cf6', '#c4b5fd', 'rgba(139,92,246,.55)'],
  ['#f59e0b', '#fcd34d', 'rgba(245,158,11,.55)'],
  ['#22c55e', '#86efac', 'rgba(34,197,94,.55)'],
]

const DEFAULT_QUERY = { scope: 'ALL', year: '2026', period: '全年', qtype: '全部' }

export default {
  name: 'RecruitDash',

  data() {
    return {
      // 常量直接挂到 data，模板里就能用（模板拿不到 import 进来的东西）
      banks: BANKS,
      years: YEARS,
      periods: PERIODS,
      qtypes: QTYPES,
      GRADES,
      GRADE_COLOR,
      TONE_DOT,
      KPI_ICONS,
      FR,

      form: { ...DEFAULT_QUERY },   // 查询条上的值（未提交）
      cur: { ...DEFAULT_QUERY },    // 已生效的查询条件（点「查询」才同步）

      riskLv: '',    // 风险预警按等级筛选
      dim: '学历',    // 入职结构环图维度
      dimpl: '',     // 漏斗绑定的计划实施
      evalImpl: '',  // 后评价绑定的计划实施
      grade: '',     // 后评价选中的考核等级
      dept: '',      // 后评价选中的部门
    }
  },

  computed: {
    /* ---------------- 查询范围文案 ---------------- */
    scopeLabel() {
      return this.cur.scope === 'ALL' ? '全省' : this.cur.scope
    },
    periodLabel() {
      return this.cur.period === '自定义起止' ? '自定义区间' : this.cur.period
    },

    /* ---------------- KPI ---------------- */
    kpiStat() {
      return planStat(this.cur.scope, this.cur.year, this.cur.qtype)
    },
    kpis() {
      const s = this.kpiStat
      return [
        {
          l: '年度计划人数', v: s.hc,
          s: `${this.cur.year}年度 · ${this.scopeLabel} · ${this.cur.qtype === '全部' ? '校招+社招' : this.cur.qtype}（已审批生效总计划）`,
          act: '查看招聘总计划 →',
          ac: 'var(--c-blue)', ac2: '#93c5fd', acs: 'var(--c-blue-s)',
        },
        {
          l: '确认入职人数', v: s.onboard,
          s: '按自然人统计 · 已登记最终入职结果',
          ac: 'var(--c-green)', ac2: '#86efac', acs: 'var(--c-green-s)',
        },
        {
          l: '剩余招聘缺口', v: s.gap,
          s: '年度计划人数 - 确认入职人数',
          ac: 'var(--c-amber)', ac2: '#fcd34d', acs: 'var(--c-amber-s)',
        },
        {
          l: '招聘完成率', v: s.rate + '%',
          s: '确认入职 ÷ 年度计划（保留1位小数）',
          ac: 'var(--c-indigo)', ac2: '#c4b5fd', acs: 'var(--c-indigo-s)',
        },
      ]
    },

    /* ---------------- 计划实施（机构 + 年度 + 类型 + 统计时间） ---------------- */
    scopeImpls() {
      const { scope, qtype, period } = this.cur
      const y = Number(this.cur.year)
      const [qs, qe] = period === '一季度'
        ? [`${y}-01-01`, `${y}-03-31`]
        : period === '二季度'
          ? [`${y}-04-01`, `${y}-06-30`]
          : ['', '']
      return implsOf(this.cur.year).filter((im) => {
        if (scope !== 'ALL' && im.org !== scope) return false
        if (qtype !== '全部' && im.type !== qtype) return false
        // 统计时间按区间重叠判：跨年度的实施只要与季度有交集就算在内
        if (qs && !(im.start <= qe && qs <= im.end)) return false
        return true
      })
    },

    /** 重点计划：先按规模筛（编制 ≥ 25 才算「重点」），再按风险优先级排序取前 5 */
    focusList() {
      const scored = this.scopeImpls.map((im) => planRisk(im, this.cur.year))
      const big = scored.filter((r) => r.im.headcount >= 25)
      const pool = big.length >= 5 ? big : scored
      return pool.sort((a, b) => b.score - a.score).slice(0, 5)
    },

    /* ---------------- 待办 / 风险 ---------------- */
    todoAll() {
      const { scope } = this.cur
      return TODOS.filter((t) => scope === 'ALL' || t.org === scope)
    },
    todos() {
      return this.todoAll.slice(0, 5)
    },
    allRisks() {
      return risksOf(this.cur.scope)
    },
    riskChips() {
      return [
        { lv: '高', cls: 'red', label: '高风险', count: this.allRisks.filter((r) => r.lv === '高').length },
        { lv: '中', cls: 'orange', label: '中风险', count: this.allRisks.filter((r) => r.lv === '中').length },
        { lv: '低', cls: 'green', label: '低风险', count: this.allRisks.filter((r) => r.lv === '低').length },
      ]
    },
    riskRows() {
      return this.allRisks.filter((r) => !this.riskLv || r.lv === this.riskLv)
    },

    /* ---------------- 漏斗 ---------------- */
    funnelImpls() {
      return this.dimpl ? this.scopeImpls.filter((im) => im.id === this.dimpl) : this.scopeImpls
    },
    funnel() {
      return funnelOf(this.funnelImpls)
    },
    funnelMax() {
      return Math.max(1, ...this.funnel.map((f) => f.v))
    },

    /* ---------------- 入职人员结构 ---------------- */
    dims() {
      // 用 KPI 的确认入职人数做总数，保证「结构合计 = 确认入职人数」
      return dimsOf(this.kpiStat.onboard, this.cur.year)
    },
    dimKeys() {
      return Object.keys(this.dims)
    },
    donutRows() {
      return this.dims[this.dim] || []
    },
    donutTotal() {
      return this.donutRows.reduce((a, b) => a + b.v, 0)
    },
    donutGrad() {
      return conicOf(this.donutRows)
    },

    /* ---------------- 招聘后评价 ---------------- */
    evalImplOpts() {
      return this.scopeImpls
        .filter((im) => im.progress.onboard > 0)
        .sort((a, b) => b.progress.onboard - a.progress.onboard)
        .slice(0, 15)
    },
    evalImplObj() {
      if (!this.evalImpl) return null
      return this.scopeImpls.find((im) => im.id === this.evalImpl) || null
    },
    evalScopeLabel() {
      if (this.evalImplObj) return `${this.evalImplObj.name}（${this.evalImplObj.org}）`
      return this.cur.scope === 'ALL' ? '全省 60 家法人行合计' : this.cur.scope
    },
    es() {
      return this.evalImplObj
        ? evalStatsImpl(this.evalImplObj)
        : evalStats(this.cur.scope, this.cur.year)
    },
    evalOrgRows() {
      const y = this.cur.year
      return LEGAL_BANKS
        .map((org) => ({ org, es: evalStats(org, y) }))
        .filter((x) => (this.grade ? x.es.cnt[this.grade] > 0 : true))
        .sort((a, b) => b.es.total - a.es.total)
    },
    dSum() {
      const rows = this.evalOrgRows
      return {
        d: rows.reduce((a, x) => a + x.es.cnt.D, 0),
        orgs: rows.filter((x) => x.es.cnt.D > 0).map((x) => x.org),
      }
    },
    gradeRank() {
      if (!this.grade) return []
      return this.es.m
        .map((r) => ({ dept: r.dept, cnt: r[this.grade] }))
        .filter((x) => x.cnt > 0)
        .sort((a, b) => b.cnt - a.cnt)
    },
    gradeMax() {
      return Math.max(1, ...this.gradeRank.map((x) => x.cnt))
    },
    deptRow() {
      if (!this.dept) return null
      return this.es.m.find((r) => r.dept === this.dept) || null
    },
    cd() {
      const cd = this.es.cnt.C + this.es.cnt.D
      const list = this.es.m
        .map((r) => ({ dept: r.dept, n: r.C + r.D }))
        .filter((x) => x.n > 0)
        .sort((a, b) => b.n - a.n)
        .map((x) => `${x.dept}（${x.n}人）`)
        .join('、')
      return { cd, list }
    },
  },

  watch: {
    // 机构 / 年度一变，下钻状态全部失效（原型在 render 里做同样的清理）
    'cur.scope'() {
      this.resetDrill()
    },
    'cur.year'() {
      this.resetDrill()
    },
    // 选中的实施被筛掉后要回退到「全部」，否则下拉显示空白但数据还在按旧 id 算
    scopeImpls(list) {
      if (this.dimpl && !list.some((im) => im.id === this.dimpl)) this.dimpl = ''
      if (this.evalImpl && !list.some((im) => im.id === this.evalImpl)) this.evalImpl = ''
    },
  },

  methods: {
    /* ---------------- 模板里要用到的纯函数 ---------------- */
    pct(a, b) {
      return pctOf(a, b)
    },
    barW(v) {
      // 最小 6%，避免「有 1 个人」时进度条看不见
      return Math.max(6, Math.round((v / this.funnelMax) * 1000) / 10)
    },
    rowPass(row) {
      const t = evalSumOf(row)
      return t ? Math.round(((t - row.D) / t) * 100) : 0
    },
    evalSumOf,
    todoTone(type) {
      return TODO_TONE[type] || 'blue'
    },
    gradeChipStyle(g) {
      const on = this.grade === g
      return {
        background: on ? GRADE_COLOR[g] : GRADE_COLOR[g] + '22',
        color: on ? '#fff' : GRADE_COLOR[g],
        borderColor: 'transparent',
      }
    },
    tip(msg) {
      this.$message({ message: msg, type: 'success', duration: 1800, showClose: true })
    },

    /* ---------------- 查询条件 ---------------- */
    onQuery() {
      this.cur = { ...this.form }
      this.tip(`已按「${this.scopeLabel} · ${this.cur.year}年度 · ${this.cur.qtype} · ${this.periodLabel}」重新统计`)
    },
    onReset() {
      this.form = { ...DEFAULT_QUERY }
      this.cur = { ...DEFAULT_QUERY }
      this.resetDrill()
      this.tip('筛选条件已重置为「全省 · 2026年度 · 全年 · 全部」')
    },
    resetDrill() {
      this.dimpl = ''
      this.evalImpl = ''
      this.grade = ''
      this.dept = ''
      this.riskLv = ''
    },
    pickOrg(org) {
      this.form.scope = org
      this.cur.scope = org
      this.resetDrill()
      this.tip(`已下钻到「${org}」，统计范围切换为该行`)
    },

    /* ---------------- KPI / 各卡片的点击 ---------------- */
    onKpi(k) {
      if (k.l === '年度计划人数') return this.tip('跳转「招聘总计划」：按当前年度与机构展示已审批生效的总计划')
      if (k.l === '确认入职人数') return this.tip('跳转「候选人管理」：已登记最终入职结果的人员明细')
      if (k.l === '剩余招聘缺口') return this.tip('缺口 = 年度计划 - 确认入职，可在「计划实施」里按缺口排序跟进')
      return this.tip('完成率随筛选条件实时计算，口径见卡片下方说明')
    },
    onViewAllImpl() {
      this.tip(`跳转「计划实施」：共 ${this.scopeImpls.length} 条实施（当前筛选范围）`)
    },
    onViewImpl(im) {
      this.tip(`进入计划实施「${im.name}」：${im.start} ~ ${im.end}，${im.status}`)
    },
    onTodoAll() {
      this.tip(`跳转「我的待办」：当前范围共 ${this.todoAll.length} 项`)
    },
    onTodoGo(t) {
      this.tip(`办理「${t.type}」：${t.title}`)
    },
    toggleRisk(lv) {
      this.riskLv = this.riskLv === lv ? '' : lv
    },
    onRiskCfg() {
      this.tip('打开「风险预警时间参数」配置：启动超期 / 停留超期 / 反馈超期 等阈值')
    },
    onRiskView(r) {
      this.tip(`查看风险「${r.name}」：${r.content}`)
    },
    onRiskUrge(r) {
      this.tip(`已向「${r.org}」发起督办（模拟接口）`)
    },
    onExport() {
      this.tip(`按当前条件导出：${this.scopeLabel} · ${this.cur.year}年度 · ${this.cur.qtype}`)
    },
    onReport() {
      this.tip('跳转「报表中心」，按当前筛选条件生成驾驶舱报表')
    },
    onGotoCandidate() {
      this.tip('跳转「候选人管理」：按当前范围查看人员明细')
    },

    /* ---------------- 后评价 ---------------- */
    toggleGrade(g) {
      this.grade = this.grade === g ? '' : g
      if (this.grade) this.dept = ''
    },
    pickDept(dept) {
      this.dept = this.dept === dept ? '' : dept
    },
    onViewPeople() {
      const scope = this.grade ? `「${this.grade}级」` : ''
      this.tip(`打开${scope}考核人员明细：${this.evalScopeLabel}，共 ${this.es.total} 人`)
    },
  },
}
</script>

<style lang="scss" scoped src="./dash.scss"></style>
